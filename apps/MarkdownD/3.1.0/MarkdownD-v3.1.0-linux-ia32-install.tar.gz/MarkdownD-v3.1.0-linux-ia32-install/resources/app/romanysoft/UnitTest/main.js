/* jshint undef:true, unused:false, eqnull:true, forin:false, freeze:true, -W004,
bitwise:true, noarg:true, sub:true, node:true,esnext:true,
notypeof:true
*/


/**
 * Created by Ian on 2015/11/22.
 */

var utilsTest = require('./utiles_test');
var menuTest = require('./menu_test');

var singleton = function singleton() {

    var t$ = this;
    t$.runAllTest = function(){
        utilsTest.run();
        menuTest.run();
    };

    //// {}
    if (singleton.caller !== singleton.getInstance) {
        throw new Error("This object cannot be instanciated");
    }
};


/* ************************************************************************
 SINGLETON CLASS DEFINITION
 ************************************************************************ */
singleton.instance = null;

/**
 * Singleton getInstance definition
 * @return singleton class
 */
singleton.getInstance = function () {
    var t$ = this;
    if (t$.instance === null) {
        t$.instance = new singleton();
    }
    return this.instance;
};



exports = module.exports = singleton.getInstance();
