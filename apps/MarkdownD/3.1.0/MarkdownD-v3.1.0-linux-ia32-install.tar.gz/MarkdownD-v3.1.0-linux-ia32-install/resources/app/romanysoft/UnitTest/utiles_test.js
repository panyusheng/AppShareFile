/* jshint undef:true, unused:false, eqnull:true, forin:false, freeze:true, -W004,
bitwise:true, browserify:true, noarg:true, sub:true, node:true,esnext:true, funcscope:true,
notypeof:true,browser: true, loopfunc:true,jquery:true
*/

/**
 * Created by Ian on 2015/11/22.
 *  测试执行实例： BS.b$.pN.unitTest.runAllTest()
 *  var utilRef = BS.b$.pN.util;
 */
var assert = require('assert');
var utilRef = require('../Classes/utils/utils');
var bugMsg = "This is a bug";



var singleton = function singleton() {
    var definedObj = {
        run: function () {
            //测试checkPathIsExist
            assert.equal(utilRef.checkPathIsExist(""), false, bugMsg);
            assert.equal(utilRef.checkPathIsExist("windows"), false, bugMsg);
            assert.equal(utilRef.checkPathIsExist("file:///d:/"), false, bugMsg);
            assert.equal(utilRef.checkPathIsExist("C:\\Windows\\assembly"), true, bugMsg);

            //测试判断是否为文件夹
            assert.equal(utilRef.checkPathIsDir(""), false, bugMsg);
            assert.equal(utilRef.checkPathIsDir("windows"), false, bugMsg);
            assert.equal(utilRef.checkPathIsDir("file:///d:/"), false, bugMsg);
            assert.equal(utilRef.checkPathIsDir("C:\\Windows\\assembly"), true, bugMsg);

            //测试判断是否为文件
            assert.equal(utilRef.checkPathIsFile(""), false, bugMsg);
            assert.equal(utilRef.checkPathIsFile("windows"), false, bugMsg);
            assert.equal(utilRef.checkPathIsFile("file:///d:/"), false, bugMsg);
            assert.equal(utilRef.checkPathIsFile("C:\\Windows\\hh.exe"), true, bugMsg);

            //判断文件是否可读
            assert.equal(utilRef.checkPathIsWritable("C:\\IcbcToolBar.txt"), true, bugMsg);
            assert.equal(utilRef.checkPathIsWritable("C:\\Windows\\hh.exe"), true, bugMsg);
            assert.equal(utilRef.checkPathIsDeletable("C:\\Windows\\hh.exe"), true, bugMsg);
            assert.equal(utilRef.checkPathIsExecutable("C:\\Windows\\hh.exe"), true, bugMsg);
            assert.equal(utilRef.checkPathIsReadable("C:\\Windows\\hh.exe"), true, bugMsg);
            assert.equal(utilRef.checkPathIsDeletable("C:"), true, bugMsg);

            //获取文件扩展名\文件名，
            assert.equal(utilRef.getFileExt("C:\\Windows\\hh.exe"), '.exe', bugMsg);
            assert.equal(utilRef.getFileExt("C:\\Windows\\hh1.exe"), '.exe', bugMsg);
            assert.equal(utilRef.getFileName("C:\\Windows\\hh1.exe"), 'hh1.exe', bugMsg);
            assert.equal(utilRef.getFileNameWithoutExt("C:\\Windows\\hh1.exe"), 'hh1', bugMsg);


            //判断算法是否准确
            assert.equal(utilRef.md5Digest("Hello23232312d#$#$#@@#@#"), 'dc9be0b50e5d3566042aaf3f8d02e3a6', bugMsg);
            assert.equal(utilRef.base64Encode("Hello23232312d#$#$#@@#@#"), 'SGVsbG8yMzIzMjMxMmQjJCMkI0BAI0Aj', bugMsg);
            assert.equal(utilRef.base64Decode("SGVsbG8yMzIzMjMxMmQjJCMkI0BAI0Aj"), 'Hello23232312d#$#$#@@#@#', bugMsg);

        }
    };
    var t$ = this;
    t$.data = definedObj;
    //// {}
    if (singleton.caller !== singleton.getInstance) {
        throw new Error("This object cannot be instanciated");
    }
};
/* ************************************************************************
 SINGLETON CLASS DEFINITION
 ************************************************************************ */
singleton.instance = null;
/**
 * Singleton getInstance definition
 * @return singleton class
 */
singleton.getInstance = function () {
    var t$ = this;
    if (t$.instance === null) {
        t$.instance = new singleton();
    }
    return this.instance.data;
};
exports = module.exports = singleton.getInstance();
