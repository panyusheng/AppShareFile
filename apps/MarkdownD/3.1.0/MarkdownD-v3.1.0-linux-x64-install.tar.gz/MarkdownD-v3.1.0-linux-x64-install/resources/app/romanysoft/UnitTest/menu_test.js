/* jshint undef:true, unused:false, eqnull:true, forin:false, freeze:true, -W004,
bitwise:true, noarg:true, sub:true, node:true,esnext:true,
notypeof:true
*/

/**
 * Created by Ian on 2015/11/22.
 *  测试执行实例： BS.b$.pN.unitTest.runAllTest()
 *  var utilRef = BS.b$.pN.util;
 */
var assert = require('assert');
var utilRef = require('../Classes/utils/utils');
var menuRef = require('../Classes/menu/menu');
var bugMsg = "This is a bug";

var singleton = function singleton() {
    var definedObj = {
        run: function () {
            //测试_getMenuItem
            assert.equal(menuRef._getMenuItem("201").role, "undo", bugMsg);
            assert.equal(menuRef._getMenuItem("202").role, "redo", bugMsg);

            //测试添加方式
            var jsonObj = {
                menuTag:202,
                title:'meme'
            };
            function changeProperty(jsonObj, key){
                menuRef.setMenuProperty(JSON.stringify(jsonObj));
                var data = menuRef._getMenuItem(jsonObj.menuTag)[key];
                console.log(data);
                return data;
            }

            assert.equal(changeProperty(jsonObj, 'role'), "redo", bugMsg);

        }
    };
    var t$ = this;
    t$.data = definedObj;
    //// {}
    if (singleton.caller !== singleton.getInstance) {
        throw new Error("This object cannot be instanciated");
    }
};
/* ************************************************************************
 SINGLETON CLASS DEFINITION
 ************************************************************************ */
singleton.instance = null;
/**
 * Singleton getInstance definition
 * @return singleton class
 */
singleton.getInstance = function () {
    var t$ = this;
    if (t$.instance === null) {
        t$.instance = new singleton();
    }
    return this.instance.data;
};
exports = module.exports = singleton.getInstance();
